import { useState } from 'react';
import axios from 'axios';
import { useSession } from 'next-auth/react';
import { toast } from 'react-hot-toast';
import Link from 'next/link';

export default function AIHelper() {
    const { data: session } = useSession();
    const [query, setQuery] = useState('');
    const [response, setResponse] = useState('');
    const [loading, setLoading] = useState(false);
    const [usage, setUsage] = useState(0);
    const [isPremium, setIsPremium] = useState(false);

    const handleSubmit = async () => {
        if (!query) return;
        if (!session) {
            return toast.error('Авторизуйтесь для использования AI');
        }
        if (!isPremium && usage >= 5) {
            return toast.error('Лимит бесплатных запросов исчерпан. Оформите подписку!');
        }

        setLoading(true);
        setResponse('');

        try {
            const res = await axios.post('/api/ai', { query, userId: session.user.id });
            setResponse(res.data.response);
            setUsage(prev => prev + 1);
        } catch (error) {
            toast.error(error.response?.data?.error || 'Ошибка при получении ответа AI');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-2xl mx-auto p-6">
            <h2 className="text-xl font-bold mb-4">AI-Помощник</h2>
            {!session ? (
                <p className="text-red-500">Авторизуйтесь, чтобы использовать AI</p>
            ) : (
                <>
                    <textarea
                        placeholder="Введите вопрос..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        className="mb-4 p-2 border rounded w-full"
                    />
                    <button onClick={handleSubmit} disabled={loading} className="bg-blue-500 text-white px-4 py-2 rounded">
                        {loading ? 'Загрузка...' : 'Отправить'}
                    </button>
                    <p className="text-sm mt-2">
                        Бесплатные запросы: {isPremium ? '∞' : `${5 - usage}/5`}{" "}
                        {!isPremium && (
                            <Link href="/subscribe">
                                <a className="text-blue-500 underline ml-2">Оформить подписку</a>
                            </Link>
                        )}
                    </p>
                </>
            )}
            {response && <p className="mt-4 p-2 border rounded">{response}</p>}
        </div>
    );
}
