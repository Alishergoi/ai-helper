import { createClient } from '@supabase/supabase-js';
import axios from 'axios';

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Метод не поддерживается' });
    }

    const { query, userId } = req.body;
    if (!query || !userId) {
        return res.status(400).json({ error: 'Неверный запрос' });
    }

    const { data: user, error } = await supabase
        .from('users')
        .select('usage_limit, is_premium')
        .eq('id', userId)
        .single();

    if (error || !user) {
        return res.status(500).json({ error: 'Ошибка получения данных пользователя' });
    }

    if (!user.is_premium && user.usage_limit >= 5) {
        return res.status(403).json({ error: 'Лимит бесплатных запросов исчерпан' });
    }

    try {
        const response = await axios.post('https://api.openai.com/v1/completions', {
            model: 'gpt-4',
            prompt: query,
            max_tokens: 500
        }, {
            headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }
        });

        if (!user.is_premium) {
            await supabase
                .from('users')
                .update({ usage_limit: user.usage_limit + 1 })
                .eq('id', userId);
        }

        res.status(200).json({ response: response.data.choices[0].text });
    } catch (error) {
        res.status(500).json({ error: 'Ошибка обработки запроса' });
    }
}
